﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDMysqlWebAPI
{
    public class APIClient
    {
        public IList<GetDataTinggiBadan> server_response;
    }

    public class GetDataTinggiBadan
    {
        public string id { get; set; }
        public string nama { get; set; }
        public string tinggi_badan { get; set; }
    }
}
