﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;

namespace CRUDMysqlWebAPI
{
    public partial class Form1 : Form
    {
        String urlApi = "http://192.168.1.15/tinggi_badan_api/readData.php";
        DataTable dataTinggiBadan = new DataTable();

        public Form1()
        {
            InitializeComponent();
        }

        public void fillDataTinggiBadan()
        {
            dgv_dataTinggiBadan.Columns.Clear();
            dataTinggiBadan.Reset();
            dataTinggiBadan = new DataTable();
            dataTinggiBadan.Rows.Clear();
            dataTinggiBadan.Columns.Clear();
            dataTinggiBadan.Clear();

            dataTinggiBadan.Columns.Add("id");
            dataTinggiBadan.Columns.Add("nama");
            dataTinggiBadan.Columns.Add("tinggi_badan");

            var apiDataTinggiBadan = this.getApiDataTinggiBadan();
            if (apiDataTinggiBadan != null)
            {
                foreach (var data in apiDataTinggiBadan.server_response)
                {
                    dataTinggiBadan.Rows.Add(new object[] {
                        data.id,
                        data.nama,
                        data.tinggi_badan
                    });
                }

                dgv_dataTinggiBadan.DataSource = dataTinggiBadan;
            }

            DataGridViewButtonColumn colEditData = new DataGridViewButtonColumn();
            colEditData.UseColumnTextForButtonValue = true;
            colEditData.Text = "Edit";
            colEditData.Name = "";
            dgv_dataTinggiBadan.Columns.Add(colEditData);

            DataGridViewButtonColumn colDeleteData = new DataGridViewButtonColumn();
            colDeleteData.UseColumnTextForButtonValue = true;
            colDeleteData.Text = "Delete";
            colDeleteData.Name = "";
            dgv_dataTinggiBadan.Columns.Add(colDeleteData);
        }

        public APIClient getApiDataTinggiBadan()
        {
            string url = urlApi;

            try
            {
                WebRequest request = WebRequest.Create(url);
                request.Credentials = new NetworkCredential();
                WebResponse webResponse = request.GetResponse();
                string jsonString = string.Empty;

                using (System.IO.StreamReader streamReader = new System.IO.StreamReader(webResponse.GetResponseStream()))
                {
                    jsonString = streamReader.ReadToEnd();
                }

                APIClient getResponse = JsonConvert.DeserializeObject<APIClient>(jsonString);
                if (getResponse == null | getResponse.server_response == null)
                {
                    return null;
                } else
                {
                    return getResponse;
                }

            } catch (WebException wex)
            {

            } catch (Exception ex)
            {

            }
            return null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fillDataTinggiBadan();

            tb_id.Enabled = false;
            tb_namaEdit.Enabled = false;
            tb_tinggiBadanEdit.Enabled = false;
            btn_save.Enabled = false;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string nama = tb_nama.Text;
            string tinggi_badan = tb_tinggiBadan.Text;

            string url = "http://192.168.1.15/tinggi_badan_api/createData.php?nama=" + nama + "&tinggi_badan=" + tinggi_badan;

            using (WebClient client = new WebClient())
            {
                string src = client.DownloadString(url);
            }

            fillDataTinggiBadan();

            tb_nama.Text = "";
            tb_tinggiBadan.Text = "";
        }

        private void dgv_dataTinggiBadan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3)
            {
                int row = Convert.ToInt32(dgv_dataTinggiBadan.CurrentCell.RowIndex.ToString());
                tb_id.Text = dgv_dataTinggiBadan.Rows[row].Cells[0].Value.ToString();
                tb_namaEdit.Text = dgv_dataTinggiBadan.Rows[row].Cells[1].Value.ToString();
                tb_tinggiBadanEdit.Text = dgv_dataTinggiBadan.Rows[row].Cells[2].Value.ToString();

                tb_namaEdit.Enabled = true;
                tb_tinggiBadanEdit.Enabled = true;
                btn_save.Enabled = true;
            }

            if (e.ColumnIndex == 4)
            {
                int row = Convert.ToInt32(dgv_dataTinggiBadan.CurrentCell.RowIndex.ToString());
                string id = tb_id.Text = dgv_dataTinggiBadan.Rows[row].Cells[0].Value.ToString();

                string url = "http://192.168.1.15/tinggi_badan_api/deleteData.php?id=" + id;

                using (WebClient client = new WebClient())
                {
                    string src = client.DownloadString(url);
                }

                fillDataTinggiBadan();
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            string id = tb_id.Text;
            string nama = tb_namaEdit.Text;
            string tinggi_badan = tb_tinggiBadanEdit.Text;

            string url = "http://192.168.1.15/tinggi_badan_api/updateData.php?id=" + id + "&nama=" + nama + "&tinggi_badan=" + tinggi_badan;

            using (WebClient client = new WebClient())
            {
                string src = client.DownloadString(url);
            }

            fillDataTinggiBadan();

            tb_namaEdit.Enabled = false;
            tb_tinggiBadanEdit.Enabled = false;
            btn_save.Enabled = false;
        }
    }
}
