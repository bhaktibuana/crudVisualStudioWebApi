<?php
require_once 'connection.php';

if ($con) {
    $nama = $_GET['nama'];
    $tinggi_badan = $_GET['tinggi_badan'];

    $insert = "INSERT INTO data_tinggi_badan(nama, tinggi_badan) VALUES('$nama', '$tinggi_badan')";

    if ($nama != "" && $tinggi_badan != "") {
        $result = mysqli_query($con, $insert);
        $response = array();

        if ($result) {
            array_push($response, array(
                'status' => 'OK'
            ));
        } else {
            array_push($response, array(
                'status' => 'FAILED'
            ));
        }
    } else {
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
} else {
    array_push($response, array(
        'status' => 'FAILED'
    ));
}

echo json_encode(array("server_response" => $response));
mysqli_close($con);
?>