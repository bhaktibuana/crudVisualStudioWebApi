<?php
require_once 'connection.php';

if ($con) {
    $id = $_GET['id'];

    $getData = "SELECT * FROM data_tinggi_badan WHERE id = '$id'";

    if ($id != "") {
        $result = mysqli_query($con, $getData);
        $rows = mysqli_num_rows($result);
        $response = array();

        if ($rows > 0) {
            $delete = "DELETE FROM data_tinggi_badan WHERE id = '$id'";
            $exequery = mysqli_query($con, $delete);

            if ($exequery) {
                array_push($response, array(
                    'status' => 'OK'
                ));
            } else {
                array_push($response, array(
                    'status' => 'FAILED'
                ));
            }
        } else {
            array_push($response, array(
                'status' => 'FAILED'
            ));
        }
    } else {
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
} else {
    array_push($response, array(
        'status' => 'FAILED'
    ));
}

echo json_encode(array("server_response" => $response));
mysqli_close($con);
?>